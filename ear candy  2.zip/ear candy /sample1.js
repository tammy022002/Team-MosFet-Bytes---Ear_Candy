import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="Header">
        <div className="Logo">Podcast Name</div>
        <nav className="Nav">
          <a href="#">Home</a>
          <a href="#">Episodes</a>
          <a href="#">About</a>
          <a href="#">Contact</a>
        </nav>
      </header>

      <section className="Hero">
        <h1>Welcome to the Podcast</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac erat ultricies, euismod arcu at, bibendum augue. Etiam vel velit blandit, sagittis odio ut, blandit mauris.</p>
        <div className="Cta">
          <a href="#">Listen Now</a>
        </div>
      </section>

      <footer className="Footer">
        <p>Copyright &copy; 2023 Podcast Name</p>
      </footer>
    </div>
  );
}

export default App;
